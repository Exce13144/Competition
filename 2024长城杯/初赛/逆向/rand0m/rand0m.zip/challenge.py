
import rand0m
flag = input("Please input: ")
if(rand0m.check(flag)):
    print("Congrats! Flag is: flag{"+flag+"}") 
else: print("Wrong! Try again!")